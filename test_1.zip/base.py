import asyncio
from datetime import datetime
from typing import List, Dict

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.collection import Collection


async def connect_to_mongo() -> Collection:
    # Параметры подключения к MongoDB
    MONGO_URI = "mongodb://localhost:27017"
    MONGO_DB = "mydatabase"
    MONGO_COLLECTION = "payments"
    
    # Подключение к MongoDB
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[MONGO_DB]
    return db[MONGO_COLLECTION]


async def aggregate_data(dt_from: datetime, dt_upto: datetime, group_type: str) -> Dict[str, List[int]]:
    collection = await connect_to_mongo()
    pipeline = [
        {"$match": {"date": {"$gte": dt_from, "$lte": dt_upto}}},
        {"$group": {"_id": {"$dateToString": {"format": group_type, "date": "$date"}}, "total": {"$sum": "$amount"}}},
        {"$sort": {"_id": 1}}
    ]
    cursor = collection.aggregate(pipeline)
    dataset = []
    labels = []
    async for document in cursor:
        labels.append(document["_id"])
        dataset.append(document["total"])
    return {"dataset": dataset, "labels": labels}


async def main():
    dt_from = datetime(2022, 9, 1)
    dt_upto = datetime(2022, 12, 31)
    group_type = "month"
    result = await aggregate_data(dt_from, dt_upto, group_type)
    print(result)


if __name__ == "__main__":
    asyncio.run(main())