# import bson
# from pymongo import MongoClient


# # with open('sample_collection.bson','rb') as f:
# #     data = bson.decode_all(f.read())

# # print(data)


# MONGO_URI = "mongodb://localhost:27017"
# DB_NAME = "test_user"
# COLLECTION_NAME = "test_user"
# FILE_PATH = "./sample_collection.bson"

# # Подключение к MongoDB
# client = MongoClient(MONGO_URI)
# db = client[DB_NAME]
# collection = db[COLLECTION_NAME]

# # Импорт данных из файла BSON в MongoDB
# with open(FILE_PATH, "rb") as f:
#     bson_data = f.read()
#     collection.insert_many(bson.decode_all(bson_data))

# print("Данные успешно импортированы в MongoDB.")


import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher, F
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from config import config
from aiogram import Router, F
from aiogram.types import Message
from motor.motor_asyncio import AsyncIOMotorClient
import motor.motor_asyncio
from datetime import datetime
from typing import List, Dict

dp = Dispatcher()
bot = Bot(config.token, parse_mode=ParseMode.MARKDOWN)

router = Router()

MONGO_URI = "mongodb://localhost:27017"
MONGO_DB = "test_user"
MONGO_COLLECTION = "test_user"


async def connect_to_mongo():
    client = AsyncIOMotorClient(MONGO_URI)
    return client[MONGO_DB][MONGO_COLLECTION]


# async def aggregate_data(dt_from: datetime, dt_upto: datetime, group_type: str):
#     collection = await connect_to_mongo()
#     pipeline = [
#         {"$match": {"date": {"$gte": dt_from, "$lte": dt_upto}}},
#         {"$group": {"_id": {"$dateToString": {"format": group_type, "date": "$date"}}, "total": {"$sum": "$amount"}}},
#         {"$sort": {"_id": 1}}
#     ]
#     cursor = collection.aggregate(pipeline)
#     dataset = []
#     labels = []
#     async for document in cursor:
#         labels.append(document["_id"])
#         dataset.append(document["total"])
#     return {"dataset": dataset, "labels": labels}



async def aggregate_data(dt_from: datetime, dt_upto: datetime, group_type: str) -> Dict[str, List[int]]:
    client = motor.motor_asyncio.AsyncIOMotorClient("mongodb://localhost:27017")
    db = client["test_user"]
    collection = db["test_user"]
    pipeline = [
        {
            "$match": {
                "dt": {"$gte": dt_from, "$lte": dt_upto}
            }
        },
        {
            "$group": {
                "_id": {"$dateToString": {"format": "%Y-%m-01T00:00:00", "date": "$dt"}},
                "total": {"$sum": "$value"}
            }
        },
        {
            "$sort": {"_id": 1}
        }
    ]

    cursor = collection.aggregate(pipeline)

    dataset = []
    labels = []

    async for document in cursor:
        dataset.append(document["total"])
        labels.append(document["_id"])

    return {"dataset": dataset, "labels": labels}

@router.message(F.text.lower() == "/start")
async def films(message: Message):
    dt_from = datetime.fromisoformat("2022-09-01T00:00:00")
    dt_upto = datetime.fromisoformat("2022-12-31T23:59:00")
    x = await aggregate_data(dt_from=dt_from, dt_upto=dt_upto, group_type="month")
    print(x)
    await message.answer(
        "Выберите какие вас интересуют фильмы"
        
    )

def set_handlers():
    dp.include_routers(router)

async def main() -> None:
    # set_middlewares()
    set_handlers()
    
    await dp.start_polling(bot)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    asyncio.run(main())